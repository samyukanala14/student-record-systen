#ifndef MERGESORT_H
#define MERGESORT_H

#include "Student.h"
#include <vector>

/**
 * @class MergeSort
 * @brief Manual implementation of the Merge Sort algorithm for Student records.
 *
 * Sorts students based on their marks in ascending or descending order.
 * Follows the Divide-and-Conquer paradigm:
 *   1. Divide: Split the array into two halves at mid = left + (right - left) / 2.
 *   2. Conquer: Recursively sort the left and right subarrays.
 *   3. Combine: Merge the two sorted subarrays into one sorted array.
 *
 * Characteristics:
 *   - Time Complexity: O(N log N) in all cases (Best, Average, Worst).
 *   - Space Complexity: O(N) auxiliary space for temporary merging.
 *   - Stability: Preserves the relative order of students with identical marks.
 */
class MergeSort {
private:
    /**
     * Merges two sorted subarrays: students[left..mid] and students[mid+1..right].
     *
     * @param students The vector of Student records.
     * @param left Starting index of the first subarray.
     * @param mid Ending index of the first subarray.
     * @param right Ending index of the second subarray.
     * @param ascending If true, sorts in ascending order (lowest to highest marks);
     *                  if false, sorts in descending order (highest to lowest marks).
     */
    static void merge(std::vector<Student>& students, int left, int mid, int right, bool ascending) {
        int n1 = mid - left + 1; // Size of left subarray
        int n2 = right - mid;     // Size of right subarray

        // Create temporary vectors for left and right subarrays
        std::vector<Student> leftArr(n1);
        std::vector<Student> rightArr(n2);

        // Copy data into temporary subarrays
        for (int i = 0; i < n1; ++i) {
            leftArr[i] = students[left + i];
        }
        for (int j = 0; j < n2; ++j) {
            rightArr[j] = students[mid + 1 + j];
        }

        // Initial indices of first and second subarrays
        int i = 0; // index for leftArr
        int j = 0; // index for rightArr
        int k = left; // initial index of merged subarray

        // Merge the temporary arrays back into students[left..right]
        while (i < n1 && j < n2) {
            bool condition = false;
            if (ascending) {
                // Ascending: smaller marks come first. <= ensures stability.
                condition = (leftArr[i].getMarks() <= rightArr[j].getMarks());
            } else {
                // Descending: higher marks come first. >= ensures stability.
                condition = (leftArr[i].getMarks() >= rightArr[j].getMarks());
            }

            if (condition) {
                students[k] = leftArr[i];
                i++;
            } else {
                students[k] = rightArr[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements of leftArr, if any
        while (i < n1) {
            students[k] = leftArr[i];
            i++;
            k++;
        }

        // Copy remaining elements of rightArr, if any
        while (j < n2) {
            students[k] = rightArr[j];
            j++;
            k++;
        }
    }

    /**
     * Recursive helper function for Merge Sort.
     *
     * @param students The vector of Student records.
     * @param left Starting index of the subarray to sort.
     * @param right Ending index of the subarray to sort.
     * @param ascending Sort order flag.
     */
    static void sortHelper(std::vector<Student>& students, int left, int right, bool ascending) {
        if (left < right) {
            // Find the midpoint avoiding overflow
            int mid = left + (right - left) / 2;

            // Step 1: Conquer left half
            sortHelper(students, left, mid, ascending);

            // Step 2: Conquer right half
            sortHelper(students, mid + 1, right, ascending);

            // Step 3: Combine both sorted halves
            merge(students, left, mid, right, ascending);
        }
    }

public:
    /**
     * Sorts the student records by marks.
     *
     * @param students Vector of student records to sort in-place.
     * @param ascending True for ascending order, false for descending order.
     */
    static void sort(std::vector<Student>& students, bool ascending = true) {
        if (students.size() <= 1) {
            return; // Already sorted
        }
        sortHelper(students, 0, static_cast<int>(students.size()) - 1, ascending);
    }
};

#endif // MERGESORT_H
