#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>
#include <iomanip>
#include <sstream>

/**
 * @class Student
 * @brief Represents a student entity in the Student Record Management System.
 *
 * Contains student attributes: ID, Name, Department, Year, Marks, and Email.
 * Provides helper methods for formatting, table display, validation, and file serialization.
 */
class Student {
private:
    int id;
    std::string name;
    std::string department;
    int year;
    double marks;
    std::string email;

public:
    // Default constructor
    Student() : id(0), name(""), department(""), year(1), marks(0.0), email("") {}

    // Parameterized constructor
    Student(int sId, const std::string& sName, const std::string& sDept, int sYear, double sMarks, const std::string& sEmail)
        : id(sId), name(sName), department(sDept), year(sYear), marks(sMarks), email(sEmail) {}

    // Getters
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getDepartment() const { return department; }
    int getYear() const { return year; }
    double getMarks() const { return marks; }
    std::string getEmail() const { return email; }

    // Setters
    void setId(int sId) { id = sId; }
    void setName(const std::string& sName) { name = sName; }
    void setDepartment(const std::string& sDept) { department = sDept; }
    void setYear(int sYear) { year = sYear; }
    void setMarks(double sMarks) { marks = sMarks; }
    void setEmail(const std::string& sEmail) { email = sEmail; }

    // Display student details in a card / summary format
    void displayCard() const {
        std::cout << "--------------------------------------------------\n";
        std::cout << " Student ID      : " << id << "\n";
        std::cout << " Student Name    : " << name << "\n";
        std::cout << " Department      : " << department << "\n";
        std::cout << " Year of Study   : " << year << "\n";
        std::cout << " Marks           : " << std::fixed << std::setprecision(2) << marks << "\n";
        std::cout << " Email Address   : " << email << "\n";
        std::cout << "--------------------------------------------------\n";
    }

    // Static helper to print table header
    static void printTableHeader() {
        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(8, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(30, '-') << "+\n";

        std::cout << "| " << std::left << std::setw(6)  << "ID"
                  << "| " << std::left << std::setw(20) << "Name"
                  << "| " << std::left << std::setw(12) << "Department"
                  << "| " << std::left << std::setw(6)  << "Year"
                  << "| " << std::left << std::setw(8)  << "Marks"
                  << "| " << std::left << std::setw(28) << "Email"
                  << "|\n";

        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(8, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(30, '-') << "+\n";
    }

    // Static helper to print table footer
    static void printTableFooter() {
        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(8, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(30, '-') << "+\n";
    }

    // Print a single student record as a formatted table row
    void printTableRow() const {
        std::cout << "| " << std::left << std::setw(6)  << id
                  << "| " << std::left << std::setw(20) << (name.length() > 20 ? name.substr(0, 17) + "..." : name)
                  << "| " << std::left << std::setw(12) << department
                  << "| " << std::left << std::setw(6)  << year
                  << "| " << std::left << std::fixed << std::setprecision(2) << std::setw(8) << marks
                  << "| " << std::left << std::setw(28) << (email.length() > 28 ? email.substr(0, 25) + "..." : email)
                  << "|\n";
    }

    // Serialize student record to pipe-delimited string for file storage
    std::string serialize() const {
        std::ostringstream oss;
        oss << id << "|" << name << "|" << department << "|" << year << "|" 
            << std::fixed << std::setprecision(2) << marks << "|" << email;
        return oss.str();
    }

    // Static validation helpers
    static bool isValidId(int id) {
        return id > 0;
    }

    static bool isValidYear(int year) {
        return (year >= 1 && year <= 4);
    }

    static bool isValidMarks(double marks) {
        return (marks >= 0.0 && marks <= 100.0);
    }

    static bool isValidEmail(const std::string& email) {
        // Simple validation: must contain '@' and '.' after '@'
        size_t atPos = email.find('@');
        size_t dotPos = email.find('.', atPos);
        return (atPos != std::string::npos && atPos > 0 && dotPos != std::string::npos && dotPos > atPos + 1);
    }
};

#endif // STUDENT_H
