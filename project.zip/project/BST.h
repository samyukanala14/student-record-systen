#ifndef BST_H
#define BST_H

#include "Student.h"
#include <iostream>
#include <vector>

/**
 * @struct BSTNode
 * @brief Node representation for the Binary Search Tree.
 */
struct BSTNode {
    Student data;
    BSTNode* left;
    BSTNode* right;

    BSTNode(const Student& s) : data(s), left(nullptr), right(nullptr) {}
};

/**
 * @class BST
 * @brief Binary Search Tree implementation keyed by Student ID.
 *
 * Provides O(log N) average time complexity for insert, search, update, and delete.
 * Includes Inorder Traversal which outputs records in ascending order of Student ID.
 */
class BST {
private:
    BSTNode* root;
    int nodeCount;

    // Helper: Recursive insertion
    BSTNode* insertHelper(BSTNode* node, const Student& s, bool& inserted) {
        if (node == nullptr) {
            inserted = true;
            nodeCount++;
            return new BSTNode(s);
        }

        if (s.getId() < node->data.getId()) {
            node->left = insertHelper(node->left, s, inserted);
        } else if (s.getId() > node->data.getId()) {
            node->right = insertHelper(node->right, s, inserted);
        } else {
            // Duplicate ID found; reject insertion
            inserted = false;
        }
        return node;
    }

    // Helper: Recursive search
    BSTNode* searchHelper(BSTNode* node, int id) const {
        if (node == nullptr || node->data.getId() == id) {
            return node;
        }
        if (id < node->data.getId()) {
            return searchHelper(node->left, id);
        }
        return searchHelper(node->right, id);
    }

    // Helper: Find the node with the minimum ID in a subtree (Inorder Successor)
    BSTNode* findMin(BSTNode* node) const {
        while (node != nullptr && node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    /**
     * Helper: Recursive deletion handling all 3 BST deletion cases:
     * Case 1: Node has 0 children (Leaf Node)
     * Case 2: Node has 1 child (Left or Right)
     * Case 3: Node has 2 children (Replaced by Inorder Successor)
     */
    BSTNode* deleteHelper(BSTNode* node, int id, bool& deleted, int& caseHandled) {
        if (node == nullptr) {
            deleted = false;
            return nullptr;
        }

        // Navigate the tree
        if (id < node->data.getId()) {
            node->left = deleteHelper(node->left, id, deleted, caseHandled);
        } else if (id > node->data.getId()) {
            node->right = deleteHelper(node->right, id, deleted, caseHandled);
        } else {
            // Found the node to delete!
            deleted = true;

            // ==============================================================
            // CASE 1: Leaf Node (No children)
            // ==============================================================
            if (node->left == nullptr && node->right == nullptr) {
                caseHandled = 1;
                delete node;
                nodeCount--;
                return nullptr;
            }

            // ==============================================================
            // CASE 2: One Child (Left or Right)
            // ==============================================================
            else if (node->left == nullptr) {
                // Has only right child
                caseHandled = 2;
                BSTNode* temp = node->right;
                delete node;
                nodeCount--;
                return temp;
            } else if (node->right == nullptr) {
                // Has only left child
                caseHandled = 2;
                BSTNode* temp = node->left;
                delete node;
                nodeCount--;
                return temp;
            }

            // ==============================================================
            // CASE 3: Two Children
            // Find Inorder Successor (smallest value in the right subtree),
            // copy its data to current node, and delete the successor.
            // ==============================================================
            else {
                caseHandled = 3;
                BSTNode* successor = findMin(node->right);
                // Copy successor data into current node
                node->data = successor->data;
                // Delete successor from right subtree
                int dummyCase = 0;
                node->right = deleteHelper(node->right, successor->data.getId(), deleted, dummyCase);
            }
        }
        return node;
    }

    // Helper: Recursive Inorder Traversal (Left -> Root -> Right)
    void inorderHelper(BSTNode* node, std::vector<Student>& list) const {
        if (node != nullptr) {
            inorderHelper(node->left, list);
            list.push_back(node->data);
            inorderHelper(node->right, list);
        }
    }

    // Helper: Free all tree memory
    void destroyTree(BSTNode* node) {
        if (node != nullptr) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }

    // Helper: Calculate height of tree
    int calculateHeight(BSTNode* node) const {
        if (node == nullptr) return 0;
        return 1 + std::max(calculateHeight(node->left), calculateHeight(node->right));
    }

public:
    BST() : root(nullptr), nodeCount(0) {}

    ~BST() {
        destroyTree(root);
        root = nullptr;
        nodeCount = 0;
    }

    int getTreeHeight() const {
        return calculateHeight(root);
    }

    // Insert student record into BST
    bool insert(const Student& s) {
        bool inserted = false;
        root = insertHelper(root, s, inserted);
        return inserted;
    }

    // Search student by ID
    bool search(int id, Student& result) const {
        BSTNode* node = searchHelper(root, id);
        if (node != nullptr) {
            result = node->data;
            return true;
        }
        return false;
    }

    // Update student details
    bool update(const Student& s) {
        BSTNode* node = searchHelper(root, s.getId());
        if (node != nullptr) {
            node->data = s;
            return true;
        }
        return false;
    }

    // Delete student record by ID, returns caseHandled (1, 2, or 3)
    bool remove(int id, int& caseHandled) {
        bool deleted = false;
        caseHandled = 0;
        root = deleteHelper(root, id, deleted, caseHandled);
        return deleted;
    }

    // Check if ID exists
    bool contains(int id) const {
        return (searchHelper(root, id) != nullptr);
    }

    // Get all students sorted by ID via Inorder Traversal
    void getInorderStudents(std::vector<Student>& list) const {
        list.clear();
        inorderHelper(root, list);
    }

    // Display formatted table of students in sorted ID order
    void displayInorder() const {
        std::vector<Student> list;
        getInorderStudents(list);

        if (list.empty()) {
            std::cout << "\n[!] No student records available in the system.\n";
            return;
        }

        std::cout << "\n=========================================================================================\n";
        std::cout << "                 STUDENT RECORDS (SORTED BY ID - BST INORDER TRAVERSAL)                  \n";
        std::cout << "=========================================================================================\n";
        Student::printTableHeader();
        for (const auto& s : list) {
            s.printTableRow();
        }
        Student::printTableFooter();
        std::cout << "Total Records: " << list.size() << "\n";
    }

    int size() const {
        return nodeCount;
    }

    bool isEmpty() const {
        return (root == nullptr);
    }

    // Clear entire tree
    void clear() {
        destroyTree(root);
        root = nullptr;
        nodeCount = 0;
    }
};

#endif // BST_H
