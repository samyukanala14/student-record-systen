# Student Record Management System Using C++ (ADSA Project)

> **Course:** Advanced Data Structures and Algorithms (ADSA)  
> **Degree Program:** BTech Computer Science & Engineering (CSE)  
> **Implementation Language:** C++ (C++17 Standard)  
> **Core ADSA Components:** Binary Search Tree (BST), Self-Balancing AVL Tree, Hash Table with Separate Chaining, Manual Merge Sort, File Persistence (`fstream`)

---

## Table of Contents
1. [Project Abstract](#1-project-abstract)
2. [Introduction](#2-introduction)
3. [Problem Statement](#3-problem-statement)
4. [Project Objectives](#4-project-objectives)
5. [Software and Hardware Requirements](#5-software-and-hardware-requirements)
6. [Data Structures and Algorithms Used](#6-data-structures-and-algorithms-used)
   - [Binary Search Tree (BST)](#a-binary-search-tree-bst)
   - [Self-Balancing AVL Tree](#b-self-balancing-avl-tree)
   - [Hash Table with Separate Chaining](#c-hash-table-with-separate-chaining)
   - [Merge Sort Algorithm](#d-merge-sort-algorithm)
7. [System Architecture and Design](#7-system-architecture-and-design)
8. [Algorithm Steps and Pseudocode](#8-algorithm-steps-and-pseudocode)
9. [Time and Space Complexity Analysis](#9-time-and-space-complexity-analysis)
10. [Sample Input and Output Walkthrough](#10-sample-input-and-output-walkthrough)
11. [Advantages and Limitations](#11-advantages-and-limitations)
12. [Future Scope](#12-future-scope)
13. [Conclusion](#13-conclusion)
14. [Windows Setup and Compilation Guide](#14-windows-setup-and-compilation-guide)
15. [ADSA Viva Questions and Answers (20 Questions)](#15-adsa-viva-questions-and-answers)

---

## 1. Project Abstract
The **Student Record Management System** is a robust, menu-driven C++ application designed for academic record management using foundational and advanced data structures. Instead of relying on generic database engines or pre-packaged STL associative containers, this project implements a custom **Binary Search Tree (BST)**, a **Self-Balancing AVL Tree**, a custom **Hash Table with Separate Chaining** for $O(1)$ average-time student searches, and a manual **Merge Sort** algorithm for stable marks-based ranking. File handling via standard C++ `fstream` guarantees data persistence across sessions. The project bridges theoretical algorithm analysis and practical software engineering.

---

## 2. Introduction
In university administration, maintaining student profiles—including identifiers, personal credentials, academic departments, year of study, marks, and official email addresses—demands both rapid single-record lookups and efficient batch operations.

Traditional flat-file or raw array approaches suffer from $O(N)$ linear search delays. Standard BSTs can degenerate into $O(N)$ linked lists when keys are inserted in sorted order. By pairing an **AVL Tree** (guaranteeing $O(\log N)$ worst-case height balance) and a **Hash Table** (for $O(1)$ key retrieval) with a **Binary Search Tree** (for dynamic order maintenance) and **Merge Sort** (for performance-guaranteed sorting), this project demonstrates how complementary data structures can be synchronized to achieve optimal operational efficiency.

---

## 3. Problem Statement
Academic institutions handle hundreds of student profiles. When operations are implemented using naive sequential data structures (like unsorted arrays or linked lists):
1. **Search Bottleneck:** Querying a student by ID requires scanning through the entire collection ($O(N)$ time).
2. **Tree Degeneration:** In standard BSTs, sequentially inserted IDs (`101, 102, 103...`) produce a skewed tree with $O(N)$ height.
3. **Sorting Overhead:** Sorting student records using basic algorithms ($O(N^2)$ Bubble or Insertion Sort) scales poorly.
4. **Data Loss:** Console applications without file persistence lose all information when terminated.

**The Solution:** Build a cohesive system utilizing:
- A **Hash Table** for constant-time ($O(1)$) student ID lookup.
- A **Binary Search Tree** for dynamic insertion, ordered retrieval ($O(N)$ inorder traversal), and structural deletions.
- A **Self-Balancing AVL Tree** with rotations to strictly bound tree height to $O(\log N)$.
- A manual **Merge Sort** algorithm providing guaranteed $O(N \log N)$ sorting of student marks.
- A persistent storage mechanism using `fstream` to serialize and deserialize records to `students.txt`.

---

## 4. Project Objectives
1. Implement a complete menu-driven console application in standard C++17.
2. Build custom data structures (BST, AVL Tree, Hash Table, Linked Nodes) from scratch without third-party libraries.
3. Implement manual Merge Sort with ascending/descending order options without losing student metadata.
4. Demonstrate the three classical cases of BST deletion (leaf node, one child, two children with Inorder Successor).
5. Implement the 4 AVL tree rotations (LL, RR, LR, RL) to maintain Balance Factor $\in \{-1, 0, +1\}$.
6. Resolve hash collisions using **Separate Chaining** with linked lists.
7. Synchronize in-memory structures seamlessly with local file storage (`students.txt`).

---

## 5. Software and Hardware Requirements
- **Language:** C++ (C++17)
- **Compiler:** GCC (MinGW-w64 `g++`)
- **IDE:** Visual Studio Code
- **Operating System:** Windows 10 / 11

---

## 6. Data Structures and Algorithms Used

### A. Binary Search Tree (BST)
- **Key:** Student ID (`int id`).
- **Invariant:** $\text{Key}(\text{LeftSubtree}(N)) < \text{Key}(N) < \text{Key}(\text{RightSubtree}(N))$
- **Operations:** Insert, Search, Inorder Traversal, Deletion (3 Cases).

### B. Self-Balancing AVL Tree
- **Balance Factor (BF):** $\text{BF}(N) = \text{Height}(\text{LeftSubtree}) - \text{Height}(\text{RightSubtree})$
- **Invariant:** For every node $N$, $\text{BF}(N) \in \{-1, 0, +1\}$.
- **Rotations:**
  - **LL Imbalance:** Single Right Rotation
  - **RR Imbalance:** Single Left Rotation
  - **LR Imbalance:** Left Rotate Child $\rightarrow$ Right Rotate Parent
  - **RL Imbalance:** Right Rotate Child $\rightarrow$ Left Rotate Parent
- **Guarantee:** Height never exceeds $1.44 \log_2 N$. Search, insert, and delete are strictly $O(\log N)$ in the worst case.

### C. Hash Table with Separate Chaining
- **Table Size:** $M = 11$ (prime number to reduce modulo clustering).
- **Hash Function:** $h(\text{id}) = \text{id} \pmod{11}$
- **Collision Handling:** Singly-linked list per bucket (**Separate Chaining**).
- **Time Complexity:** $O(1)$ average search, insert, and delete.

### D. Merge Sort Algorithm
- **Paradigm:** Divide-and-Conquer.
- **Complexity:** $O(N \log N)$ in all cases (Best, Average, Worst).
- **Stability:** Preserved using `<=` and `>=` during merge.

---

## 7. System Architecture and Design

```
                     +---------------------------------------+
                     |         User Interface / Menu         |
                     |              (main.cpp)               |
                     +-------------------+-------------------+
                                         |
            +----------------------------+----------------------------+
            |                            |                            |
            v                            v                            v
+-----------------------+    +-----------------------+    +-----------------------+
|  Binary Search Tree   |    |       AVL Tree        |    |      Hash Table       |
|        (BST.h)        |    |      (AVLTree.h)      |    |     (HashTable.h)     |
| - Keyed by Student ID |    | - Self-Balancing      |    | - Chained Buckets (11)|
| - Inorder Traversal   |    | - Rotations (LL,RR..) |    | - O(1) Instant Search |
| - 3 Deletion Cases    |    | - O(log N) Guaranteed |    | - Collision Handling  |
+-----------+-----------+    +-----------+-----------+    +-----------+-----------+
            |                            |                            |
            +----------------------------+----------------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |             Student Entity            |
                     |              (Student.h)              |
                     |  ID, Name, Dept, Year, Marks, Email   |
                     +-------------------+-------------------+
                                         |
                                         v
                     +---------------------------------------+
                     |             File Manager              |
                     |            (FileManager.h)            |
                     |   Reads/Writes from 'students.txt'    |
                     +---------------------------------------+
```

---

## 8. Time and Space Complexity Analysis

| Operation / Algorithm | Best Case Time | Average Case Time | Worst Case Time | Space Complexity |
| :--- | :--- | :--- | :--- | :--- |
| **BST Search** | $O(1)$ | $O(\log N)$ | $O(N)$ (Skewed tree) | $O(\log N)$ stack |
| **AVL Tree Search** | $O(1)$ | $O(\log N)$ | $\mathbf{O(\log N)}$ (Guaranteed) | $O(\log N)$ stack |
| **AVL Tree Insert** | $O(1)$ | $O(\log N)$ | $\mathbf{O(\log N)}$ (Guaranteed) | $O(\log N)$ stack |
| **AVL Tree Delete** | $O(1)$ | $O(\log N)$ | $\mathbf{O(\log N)}$ (Guaranteed) | $O(\log N)$ stack |
| **Hash Table Search** | $O(1)$ | $\mathbf{O(1)}$ | $O(N)$ (All collide) | $O(1)$ |
| **Hash Table Insert** | $O(1)$ | $\mathbf{O(1)}$ | $O(N)$ (All collide) | $O(1)$ |
| **Merge Sort** | $O(N \log N)$ | $O(N \log N)$ | $O(N \log N)$ | $O(N)$ merge buffer |
| **File Load / Save** | $O(N)$ | $O(N)$ | $O(N)$ | $O(N)$ buffer |

---

## 9. ADSA Viva Questions and Answers

### Q1: Why use both an AVL Tree and a Hash Table?
**Answer:** A Hash Table provides extremely fast $O(1)$ average-time retrieval, but it is unordered and cannot perform range queries or sorted traversal. An AVL Tree maintains strict sorted hierarchical order, guarantees $O(\log N)$ worst-case search, and allows $O(N)$ Inorder Traversal. Using both provides optimal lookup and optimal ordered display.

### Q2: What is the Balance Factor in an AVL Tree?
**Answer:** The Balance Factor of a node is the height of its left subtree minus the height of its right subtree: $\text{BF} = \text{Height}(\text{Left}) - \text{Height}(\text{Right})$. In an AVL tree, BF must be in $\{-1, 0, +1\}$ for every node.

### Q3: Name the 4 AVL rotation types.
**Answer:** 
1. Left-Left (LL) Imbalance $\rightarrow$ Single Right Rotation
2. Right-Right (RR) Imbalance $\rightarrow$ Single Left Rotation
3. Left-Right (LR) Imbalance $\rightarrow$ Left Rotate child, then Right Rotate parent
4. Right-Left (RL) Imbalance $\rightarrow$ Right Rotate child, then Left Rotate parent

### Q4: When does a standard BST degenerate into $O(N)$ worst-case?
**Answer:** When keys are inserted in strictly ascending or descending sorted order. An AVL Tree prevents this by executing rotations whenever balance factor deviates beyond $\pm 1$.

### Q5: How does your Hash Table handle collisions?
**Answer:** Using **Separate Chaining**. Each bucket is a linked list. Colliding elements (such as IDs 101 and 112 in Bucket 2) are chained together using `HashNode* next` pointers.
