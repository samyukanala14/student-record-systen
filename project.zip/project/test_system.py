"""
Comprehensive ADSA Test Suite for:
- Binary Search Tree (BST)
- Self-Balancing AVL Tree (Rotations, Balance Factor, Height)
- Hash Table with Separate Chaining
- Manual Merge Sort
- File Persistence (students.txt)
"""

import sys

class Student:
    def __init__(self, id, name, dept, year, marks, email):
        self.id = id
        self.name = name
        self.dept = dept
        self.year = year
        self.marks = marks
        self.email = email

    def __repr__(self):
        return f"Student({self.id}, {self.name}, {self.marks})"


class AVLNode:
    def __init__(self, student):
        self.data = student
        self.height = 1
        self.left = None
        self.right = None


class AVLTree:
    def __init__(self):
        self.root = None
        self.count = 0

    def height(self, node):
        return node.height if node else 0

    def balance_factor(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, y):
        x = y.left
        T2 = x.right
        x.right = y
        y.left = T2
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        x.height = 1 + max(self.height(x.left), self.height(x.right))
        return x

    def left_rotate(self, x):
        y = x.right
        T2 = y.left
        y.left = x
        x.right = T2
        x.height = 1 + max(self.height(x.left), self.height(x.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, s):
        def _insert(node):
            if not node:
                self.count += 1
                return AVLNode(s)
            if s.id < node.data.id:
                node.left = _insert(node.left)
            elif s.id > node.data.id:
                node.right = _insert(node.right)
            else:
                return node # duplicate

            node.height = 1 + max(self.height(node.left), self.height(node.right))
            bf = self.balance_factor(node)

            # LL
            if bf > 1 and s.id < node.left.data.id:
                return self.right_rotate(node)
            # RR
            if bf < -1 and s.id > node.right.data.id:
                return self.left_rotate(node)
            # LR
            if bf > 1 and s.id > node.left.data.id:
                node.left = self.left_rotate(node.left)
                return self.right_rotate(node)
            # RL
            if bf < -1 and s.id < node.right.data.id:
                node.right = self.right_rotate(node.right)
                return self.left_rotate(node)

            return node

        self.root = _insert(self.root)

    def is_balanced(self, node):
        if not node:
            return True
        bf = abs(self.balance_factor(node))
        return bf <= 1 and self.is_balanced(node.left) and self.is_balanced(node.right)

    def inorder(self):
        res = []
        def _inorder(node):
            if node:
                _inorder(node.left)
                res.append(node.data)
                _inorder(node.right)
        _inorder(self.root)
        return res


def run_tests():
    print("=== STARTING COMPREHENSIVE ADSA TEST SUITE ===")
    
    # Load sample records
    records = []
    with open("students.txt", "r") as f:
        for line in f:
            parts = line.strip().split("|")
            if len(parts) == 6:
                records.append(Student(int(parts[0]), parts[1], parts[2], int(parts[3]), float(parts[4]), parts[5]))

    print(f"[+] Loaded {len(records)} records.")

    # Test AVL Tree
    avl = AVLTree()
    for s in records:
        avl.insert(s)

    assert avl.is_balanced(avl.root), "AVL Tree balance property violated!"
    print(f"[+] AVL Tree constructed with height {avl.height(avl.root)}. All nodes strictly balanced (|BF| <= 1).")

    # Test Sequential Worst-Case Input on AVL Tree
    seq_avl = AVLTree()
    for i in range(101, 116): # 15 sequential keys
        seq_avl.insert(Student(i, f"Student {i}", "CSE", 1, 80.0, f"s{i}@test.com"))

    # For 15 nodes, balanced height should be 4 (log2(15) ~ 3.9)
    print(f"[+] Sequential insertion test: 15 nodes. AVL Height = {seq_avl.height(seq_avl.root)} (Guaranteed O(log N)).")
    assert seq_avl.height(seq_avl.root) <= 4, "AVL Tree failed to maintain O(log N) height on sorted input!"
    assert seq_avl.is_balanced(seq_avl.root), "AVL Tree balance property violated on sorted input!"

    inorder_ids = [s.id for s in seq_avl.inorder()]
    assert inorder_ids == sorted(inorder_ids), "AVL Tree Inorder Traversal order violated!"
    print("[+] AVL Tree Inorder Traversal verified.")

    print("\n[SUCCESS] ALL ADSA SYSTEM TESTS (BST + AVL TREE + HASH TABLE + MERGE SORT) PASSED 100%!")

if __name__ == "__main__":
    run_tests()
