@echo off
setlocal enabledelayedexpansion

echo ========================================================
echo   Student Record Management System - Build & Run
echo ========================================================
echo.

set "GXX="

:: 1. Check if g++ is already in system PATH
where g++ >nul 2>nul
if %errorlevel% equ 0 (
    set "GXX=g++"
    goto :FOUND
)

:: 2. Auto-detect common extracted w64devkit and MinGW paths
if exist "C:\w64devkit\bin\g++.exe" (
    set "GXX=C:\w64devkit\bin\g++.exe"
    set "PATH=C:\w64devkit\bin;%PATH%"
    goto :FOUND
)
if exist "%USERPROFILE%\Downloads\w64devkit\bin\g++.exe" (
    set "GXX=%USERPROFILE%\Downloads\w64devkit\bin\g++.exe"
    set "PATH=%USERPROFILE%\Downloads\w64devkit\bin;%PATH%"
    goto :FOUND
)
if exist "%USERPROFILE%\Downloads\w64devkit-1.23.0\w64devkit\bin\g++.exe" (
    set "GXX=%USERPROFILE%\Downloads\w64devkit-1.23.0\w64devkit\bin\g++.exe"
    set "PATH=%USERPROFILE%\Downloads\w64devkit-1.23.0\w64devkit\bin;%PATH%"
    goto :FOUND
)
if exist "%USERPROFILE%\Downloads\w64devkit-1.23.0\bin\g++.exe" (
    set "GXX=%USERPROFILE%\Downloads\w64devkit-1.23.0\bin\g++.exe"
    set "PATH=%USERPROFILE%\Downloads\w64devkit-1.23.0\bin;%PATH%"
    goto :FOUND
)
if exist "C:\mingw64\bin\g++.exe" (
    set "GXX=C:\mingw64\bin\g++.exe"
    set "PATH=C:\mingw64\bin;%PATH%"
    goto :FOUND
)
if exist "C:\msys64\ucrt64\bin\g++.exe" (
    set "GXX=C:\msys64\ucrt64\bin\g++.exe"
    set "PATH=C:\msys64\ucrt64\bin;%PATH%"
    goto :FOUND
)
if exist "C:\msys64\mingw64\bin\g++.exe" (
    set "GXX=C:\msys64\mingw64\bin\g++.exe"
    set "PATH=C:\msys64\mingw64\bin;%PATH%"
    goto :FOUND
)

:: Not found anywhere
echo [ERROR] 'g++' compiler not found.
echo.
echo Please extract the downloaded 'w64devkit-1.23.0.zip':
echo 1. Open your Downloads folder.
echo 2. Right-click 'w64devkit-1.23.0.zip' and click 'Extract All...'
echo 3. Just click 'Extract' (or extract to C:\w64devkit).
echo 4. Run this script again!
echo.
pause
exit /b 1

:FOUND
echo [+] Found C++ compiler: !GXX!
echo Compiling main.cpp with C++17...
"!GXX!" -std=c++17 -Wall main.cpp -o StudentManagement.exe

if %errorlevel% equ 0 (
    echo.
    echo [SUCCESS] Compilation successful!
    echo ========================================================
    echo Launching Student Record Management System...
    echo ========================================================
    echo.
    StudentManagement.exe
) else (
    echo.
    echo [ERROR] Compilation failed. Please check the error messages above.
)

pause
