#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include "Student.h"
#include "BST.h"
#include "AVLTree.h"
#include "HashTable.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <iostream>

/**
 * @class FileManager
 * @brief Handles file persistence for Student records using C++ fstream.
 *
 * Persists student records to a text file using a pipe-delimited format:
 *   ID|Name|Department|Year|Marks|Email
 *
 * Synchronizes loaded records across the Binary Search Tree, AVL Tree, and Hash Table.
 */
class FileManager {
public:
    /**
     * Saves all student records to a specified file.
     *
     * @param filename Path of the file to save to.
     * @param records List of student records to write.
     * @return true if save succeeded, false otherwise.
     */
    static bool saveRecords(const std::string& filename, const std::vector<Student>& records) {
        std::ofstream outFile(filename);
        if (!outFile.is_open()) {
            std::cerr << "[!] Error: Could not open file for writing: " << filename << "\n";
            return false;
        }

        for (const auto& s : records) {
            outFile << s.serialize() << "\n";
        }

        outFile.close();
        return true;
    }

    /**
     * Loads student records from a file and inserts them into BST, AVL Tree, and HashTable.
     *
     * @param filename Path of the file to load from.
     * @param bst Reference to the Binary Search Tree.
     * @param avl Reference to the self-balancing AVL Tree.
     * @param ht Reference to the Hash Table.
     * @param loadedCount Output parameter tracking the number of records loaded.
     * @return true if file was opened and processed, false if file could not be opened.
     */
    static bool loadRecords(const std::string& filename, BST& bst, AVLTree& avl, HashTable& ht, int& loadedCount) {
        std::ifstream inFile(filename);
        loadedCount = 0;

        if (!inFile.is_open()) {
            // File does not exist yet (e.g., first run)
            return false;
        }

        std::string line;
        while (std::getline(inFile, line)) {
            // Skip empty lines
            if (line.empty()) continue;

            std::stringstream ss(line);
            std::string idStr, name, dept, yearStr, marksStr, email;

            if (std::getline(ss, idStr, '|') &&
                std::getline(ss, name, '|') &&
                std::getline(ss, dept, '|') &&
                std::getline(ss, yearStr, '|') &&
                std::getline(ss, marksStr, '|') &&
                std::getline(ss, email)) {
                
                try {
                    int id = std::stoi(idStr);
                    int year = std::stoi(yearStr);
                    double marks = std::stod(marksStr);

                    Student s(id, name, dept, year, marks, email);
                    // Insert into all three data structures
                    bool bstSuccess = bst.insert(s);
                    bool avlSuccess = avl.insert(s);
                    bool htSuccess  = ht.insert(s);

                    if (bstSuccess && avlSuccess && htSuccess) {
                        loadedCount++;
                    }
                } catch (const std::exception& e) {
                    std::cerr << "[!] Warning: Skipping malformed line in file: " << line << "\n";
                }
            }
        }

        inFile.close();
        return true;
    }
};

#endif // FILEMANAGER_H
