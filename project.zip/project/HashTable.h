#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "Student.h"
#include <iostream>
#include <vector>
#include <iomanip>

/**
 * @struct HashNode
 * @brief Node for separate chaining linked list in the Hash Table.
 */
struct HashNode {
    Student data;
    HashNode* next;

    HashNode(const Student& s) : data(s), next(nullptr) {}
};

/**
 * @class HashTable
 * @brief Hash Table implementation with Separate Chaining for collision resolution.
 *
 * Uses division-based hash function keyed by Student ID.
 * Provides O(1) average time complexity for insert, search, update, and delete.
 */
class HashTable {
private:
    static const int TABLE_SIZE = 11; // Prime number chosen to minimize hash collisions
    HashNode* table[TABLE_SIZE];
    int totalElements;

    // Hash Function: Division Method
    int hashFunction(int id) const {
        return (id % TABLE_SIZE + TABLE_SIZE) % TABLE_SIZE;
    }

public:
    HashTable() : totalElements(0) {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            table[i] = nullptr;
        }
    }

    ~HashTable() {
        clear();
    }

    // Insert student into Hash Table
    // Returns true on success, false if duplicate ID exists
    bool insert(const Student& s) {
        int index = hashFunction(s.getId());
        HashNode* current = table[index];

        // Check if student with duplicate ID already exists in this chain
        while (current != nullptr) {
            if (current->data.getId() == s.getId()) {
                return false; // Duplicate found
            }
            current = current->next;
        }

        // Insert new node at the head of the chain (O(1) insertion)
        HashNode* newNode = new HashNode(s);
        newNode->next = table[index];
        table[index] = newNode;
        totalElements++;
        return true;
    }

    // Search student by ID (returns pointer to student for direct viewing/updating)
    Student* search(int id) {
        int index = hashFunction(id);
        HashNode* current = table[index];

        while (current != nullptr) {
            if (current->data.getId() == id) {
                return &(current->data);
            }
            current = current->next;
        }
        return nullptr; // Not found
    }

    // Const overload for search
    bool search(int id, Student& result) const {
        int index = hashFunction(id);
        HashNode* current = table[index];

        while (current != nullptr) {
            if (current->data.getId() == id) {
                result = current->data;
                return true;
            }
            current = current->next;
        }
        return false;
    }

    // Update existing student details
    bool update(const Student& s) {
        Student* found = search(s.getId());
        if (found != nullptr) {
            *found = s;
            return true;
        }
        return false;
    }

    // Delete student record by ID
    bool remove(int id) {
        int index = hashFunction(id);
        HashNode* current = table[index];
        HashNode* prev = nullptr;

        while (current != nullptr) {
            if (current->data.getId() == id) {
                if (prev == nullptr) {
                    // Node is head of bucket list
                    table[index] = current->next;
                } else {
                    // Node is in middle or end of bucket list
                    prev->next = current->next;
                }
                delete current;
                totalElements--;
                return true;
            }
            prev = current;
            current = current->next;
        }
        return false; // Not found
    }

    // Collect all students stored across all buckets
    void getAllStudents(std::vector<Student>& list) const {
        list.clear();
        for (int i = 0; i < TABLE_SIZE; ++i) {
            HashNode* current = table[i];
            while (current != nullptr) {
                list.push_back(current->data);
                current = current->next;
            }
        }
    }

    // Viva & Demonstration Feature: Visualize Hash Buckets & Separate Chaining
    void displayBucketChains() const {
        std::cout << "\n=================================================================\n";
        std::cout << "        HASH TABLE BUCKET VISUALIZATION (SEPARATE CHAINING)       \n";
        std::cout << "=================================================================\n";
        std::cout << "Table Size: " << TABLE_SIZE << " | Total Records: " << totalElements << "\n";
        std::cout << "Hash Function: hash(ID) = ID % " << TABLE_SIZE << "\n";
        std::cout << "-----------------------------------------------------------------\n";

        for (int i = 0; i < TABLE_SIZE; ++i) {
            std::cout << "Bucket [" << std::setw(2) << i << "]: ";
            HashNode* current = table[i];
            if (current == nullptr) {
                std::cout << "(empty)\n";
            } else {
                while (current != nullptr) {
                    std::cout << "[ID: " << current->data.getId() 
                              << " | " << current->data.getName() << "] -> ";
                    current = current->next;
                }
                std::cout << "NULL\n";
            }
        }
        std::cout << "=================================================================\n";
    }

    int size() const {
        return totalElements;
    }

    bool isEmpty() const {
        return totalElements == 0;
    }

    // Clear all elements and free allocated memory
    void clear() {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            HashNode* current = table[i];
            while (current != nullptr) {
                HashNode* temp = current;
                current = current->next;
                delete temp;
            }
            table[i] = nullptr;
        }
        totalElements = 0;
    }
};

#endif // HASHTABLE_H
