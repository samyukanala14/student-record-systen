#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include "Student.h"
#include "BST.h"
#include "AVLTree.h"
#include "HashTable.h"
#include "MergeSort.h"
#include "FileManager.h"

// Constant for persistent storage filename
const std::string DATA_FILE = "students.txt";

// ============================================================================
// HELPER INPUT FUNCTIONS (Robust input validation and buffer handling)
// ============================================================================

/**
 * Clears any error state and remaining characters in std::cin.
 */
void clearInputBuffer() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

/**
 * Prompts user for an integer within an optional range.
 */
int readInt(const std::string& prompt, int minVal = std::numeric_limits<int>::min(), int maxVal = std::numeric_limits<int>::max()) {
    int value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            if (value >= minVal && value <= maxVal) {
                clearInputBuffer();
                return value;
            } else {
                std::cout << "[!] Please enter a value between " << minVal << " and " << maxVal << ".\n";
            }
        } else {
            std::cout << "[!] Invalid input. Please enter a valid number.\n";
            clearInputBuffer();
        }
    }
}

/**
 * Prompts user for a double within a range (e.g. marks 0.0 to 100.0).
 */
double readDouble(const std::string& prompt, double minVal = 0.0, double maxVal = 100.0) {
    double value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            if (value >= minVal && value <= maxVal) {
                clearInputBuffer();
                return value;
            } else {
                std::cout << "[!] Please enter marks between " << minVal << " and " << maxVal << ".\n";
            }
        } else {
            std::cout << "[!] Invalid input. Please enter a valid numeric value.\n";
            clearInputBuffer();
        }
    }
}

/**
 * Reads a non-empty string line from standard input.
 */
std::string readLine(const std::string& prompt) {
    std::string text;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, text);
        // Trim leading and trailing whitespace
        size_t start = text.find_first_not_of(" \t\r\n");
        if (start != std::string::npos) {
            size_t end = text.find_last_not_of(" \t\r\n");
            return text.substr(start, end - start + 1);
        }
        std::cout << "[!] Input cannot be empty. Please try again.\n";
    }
}

/**
 * Reads an optional string line (allows pressing Enter to keep old value during update).
 */
std::string readOptionalLine(const std::string& prompt, const std::string& currentValue) {
    std::cout << prompt << " [" << currentValue << "]: ";
    std::string text;
    std::getline(std::cin, text);
    size_t start = text.find_first_not_of(" \t\r\n");
    if (start != std::string::npos) {
        size_t end = text.find_last_not_of(" \t\r\n");
        return text.substr(start, end - start + 1);
    }
    return currentValue;
}

// ============================================================================
// MENU ACTION HANDLERS
// ============================================================================

/**
 * 1. Add Student
 * Synchronously inserts into BST, AVL Tree, and Hash Table.
 */
void handleAddStudent(BST& bst, AVLTree& avl, HashTable& ht) {
    std::cout << "\n--------------------------------------------------\n";
    std::cout << "                 ADD NEW STUDENT                  \n";
    std::cout << "--------------------------------------------------\n";

    int id = readInt("Enter Student ID (positive integer): ", 1);

    // ADSA duplicate check: Check Hash Table
    if (ht.search(id) != nullptr) {
        std::cout << "\n[!] Error: Student with ID " << id << " already exists in the system!\n";
        std::cout << "    Duplicate student IDs are not allowed.\n";
        return;
    }

    std::string name = readLine("Enter Student Name: ");
    std::string dept = readLine("Enter Department (e.g. CSE, ECE, MECH): ");
    int year = readInt("Enter Year of Study (1-4): ", 1, 4);
    double marks = readDouble("Enter Marks (0.0 - 100.0): ", 0.0, 100.0);

    std::string email;
    while (true) {
        email = readLine("Enter Email Address: ");
        if (Student::isValidEmail(email)) {
            break;
        }
        std::cout << "[!] Invalid email format (must contain '@' and domain like '.edu' or '.com').\n";
    }

    Student newStudent(id, name, dept, year, marks, email);

    // Insert into BST, AVL Tree, and Hash Table
    bool bstSuccess = bst.insert(newStudent);
    bool avlSuccess = avl.insert(newStudent);
    bool htSuccess  = ht.insert(newStudent);

    if (bstSuccess && avlSuccess && htSuccess) {
        std::cout << "\n[+] Success: Student record added successfully!\n";
        std::cout << "    [BST]      Inserted Node with Key ID: " << id << "\n";
        std::cout << "    [AVL Tree] Inserted Node with automatic height rebalancing\n";
        std::cout << "    [HashTable] Chained into bucket index: " << (id % 11) << "\n";
    } else {
        std::cout << "\n[!] Error occurred while inserting into data structures.\n";
    }
}

/**
 * 2. Display All Students
 */
void handleDisplayAll(const BST& bst) {
    std::vector<Student> list;
    bst.getInorderStudents(list);

    if (list.empty()) {
        std::cout << "\n[!] No student records found. System is currently empty.\n";
        return;
    }

    std::cout << "\n=========================================================================================\n";
    std::cout << "                                ALL STUDENT RECORDS                                      \n";
    std::cout << "=========================================================================================\n";
    Student::printTableHeader();
    for (const auto& s : list) {
        s.printTableRow();
    }
    Student::printTableFooter();
    std::cout << "Total Records: " << list.size() << "\n";
}

/**
 * 3. Search Student by ID (O(1) Hash Table)
 */
void handleSearchStudent(HashTable& ht) {
    std::cout << "\n--------------------------------------------------\n";
    std::cout << "              SEARCH STUDENT BY ID                \n";
    std::cout << "--------------------------------------------------\n";

    int id = readInt("Enter Student ID to search: ", 1);

    // Fast O(1) lookup via Hash Table
    Student* s = ht.search(id);

    if (s != nullptr) {
        std::cout << "\n[+] Student Record Found (Retrieved via Hash Table in O(1) time):\n";
        s->displayCard();
        std::cout << "    [Hash Table Info] Located in Bucket: " << (id % 11) << "\n";
    } else {
        std::cout << "\n[!] Student with ID " << id << " was not found in the records.\n";
    }
}

/**
 * 4. Update Student Details
 * Synchronizes update across BST, AVL Tree, and Hash Table.
 */
void handleUpdateStudent(BST& bst, AVLTree& avl, HashTable& ht) {
    std::cout << "\n--------------------------------------------------\n";
    std::cout << "              UPDATE STUDENT DETAILS              \n";
    std::cout << "--------------------------------------------------\n";

    int id = readInt("Enter Student ID to update: ", 1);

    Student* current = ht.search(id);
    if (current == nullptr) {
        std::cout << "\n[!] Student with ID " << id << " does not exist. Cannot update.\n";
        return;
    }

    std::cout << "\n[i] Current details for Student ID " << id << ":\n";
    current->displayCard();
    std::cout << "Press Enter to keep current value, or type a new value:\n";

    std::string newName = readOptionalLine("Enter New Name", current->getName());
    std::string newDept = readOptionalLine("Enter New Department", current->getDepartment());

    // Update Year
    int newYear = current->getYear();
    std::cout << "Enter New Year of Study (1-4) [" << newYear << "]: ";
    std::string yearInput;
    std::getline(std::cin, yearInput);
    if (!yearInput.empty()) {
        try {
            int y = std::stoi(yearInput);
            if (Student::isValidYear(y)) {
                newYear = y;
            } else {
                std::cout << "[!] Invalid year entered. Retaining previous year (" << newYear << ").\n";
            }
        } catch (...) {
            std::cout << "[!] Invalid numeric input. Retaining previous year (" << newYear << ").\n";
        }
    }

    // Update Marks
    double newMarks = current->getMarks();
    std::cout << "Enter New Marks (0.0 - 100.0) [" << newMarks << "]: ";
    std::string marksInput;
    std::getline(std::cin, marksInput);
    if (!marksInput.empty()) {
        try {
            double m = std::stod(marksInput);
            if (Student::isValidMarks(m)) {
                newMarks = m;
            } else {
                std::cout << "[!] Invalid marks entered. Retaining previous marks (" << newMarks << ").\n";
            }
        } catch (...) {
            std::cout << "[!] Invalid numeric input. Retaining previous marks (" << newMarks << ").\n";
        }
    }

    // Update Email
    std::string newEmail = current->getEmail();
    std::string emailInput = readOptionalLine("Enter New Email", current->getEmail());
    if (emailInput != current->getEmail()) {
        if (Student::isValidEmail(emailInput)) {
            newEmail = emailInput;
        } else {
            std::cout << "[!] Invalid email format. Retaining previous email (" << newEmail << ").\n";
        }
    }

    // Build updated student object
    Student updatedStudent(id, newName, newDept, newYear, newMarks, newEmail);

    // Synchronize all three data structures
    bool htOk  = ht.update(updatedStudent);
    bool bstOk = bst.update(updatedStudent);
    bool avlOk = avl.update(updatedStudent);

    if (htOk && bstOk && avlOk) {
        std::cout << "\n[+] Success: Student details updated successfully across BST, AVL Tree, and Hash Table!\n";
        std::cout << "\nUpdated Record Summary:\n";
        updatedStudent.displayCard();
    } else {
        std::cout << "\n[!] Error: Failed to synchronize update across data structures.\n";
    }
}

/**
 * 5. Delete Student Record
 * Deletes from BST (explaining Case 1, 2, or 3), AVL Tree (self-balancing), and Hash Table.
 */
void handleDeleteStudent(BST& bst, AVLTree& avl, HashTable& ht) {
    std::cout << "\n--------------------------------------------------\n";
    std::cout << "              DELETE STUDENT RECORD               \n";
    std::cout << "--------------------------------------------------\n";

    int id = readInt("Enter Student ID to delete: ", 1);

    if (ht.search(id) == nullptr) {
        std::cout << "\n[!] Student with ID " << id << " was not found. Nothing to delete.\n";
        return;
    }

    std::cout << "Are you sure you want to permanently delete Student ID " << id << "? (y/n): ";
    char confirm;
    std::cin >> confirm;
    clearInputBuffer();

    if (confirm != 'y' && confirm != 'Y') {
        std::cout << "[*] Deletion cancelled by user.\n";
        return;
    }

    int caseHandled = 0;
    bool bstRemoved = bst.remove(id, caseHandled);
    bool avlRemoved = avl.remove(id);
    bool htRemoved  = ht.remove(id);

    if (bstRemoved && avlRemoved && htRemoved) {
        std::cout << "\n[+] Success: Student ID " << id << " deleted successfully across all structures!\n";
        std::cout << "--------------------------------------------------\n";
        std::cout << " ADSA BST DELETION CASE EXPLANATION:\n";
        if (caseHandled == 1) {
            std::cout << " Case 1: Leaf Node Deletion\n";
            std::cout << " -> The deleted node had 0 children. It was deleted and its parent link set to NULL.\n";
        } else if (caseHandled == 2) {
            std::cout << " Case 2: Single Child Deletion\n";
            std::cout << " -> The deleted node had 1 child. The node was replaced by its child subtree.\n";
        } else if (caseHandled == 3) {
            std::cout << " Case 3: Two Children Deletion\n";
            std::cout << " -> The deleted node had 2 children. It was replaced by its Inorder Successor\n";
            std::cout << "    (the minimum key in the right subtree), and the successor node was then removed.\n";
        }
        std::cout << " [AVL Tree] Node removed and tree rebalanced with height: " << avl.getTreeHeight() << "\n";
        std::cout << " [Hash Table] Node removed from bucket chain index: " << (id % 11) << "\n";
        std::cout << "--------------------------------------------------\n";
    } else {
        std::cout << "\n[!] Error during deletion from data structures.\n";
    }
}

/**
 * 6. Sort Students by Marks (Merge Sort)
 */
void handleSortByMarks(const BST& bst) {
    std::vector<Student> list;
    bst.getInorderStudents(list);

    if (list.empty()) {
        std::cout << "\n[!] No student records available to sort.\n";
        return;
    }

    std::cout << "\n--------------------------------------------------\n";
    std::cout << "            SORT STUDENTS BY MARKS                \n";
    std::cout << "--------------------------------------------------\n";
    std::cout << "1. Ascending Order (Lowest to Highest Marks)\n";
    std::cout << "2. Descending Order (Highest to Lowest Marks)\n";
    int choice = readInt("Enter your choice (1 or 2): ", 1, 2);

    bool ascending = (choice == 1);

    // Perform manual Merge Sort
    MergeSort::sort(list, ascending);

    std::cout << "\n=========================================================================================\n";
    std::cout << "               STUDENT RECORDS (SORTED BY MARKS - " 
              << (ascending ? "ASCENDING" : "DESCENDING") << ")                        \n";
    std::cout << "=========================================================================================\n";
    Student::printTableHeader();
    for (const auto& s : list) {
        s.printTableRow();
    }
    Student::printTableFooter();
    std::cout << "Total Records: " << list.size() << "\n";
    std::cout << "\n[ADSA Note] Sorted using Divide-and-Conquer Merge Sort.\n";
    std::cout << "  - Time Complexity: O(N log N) (Best, Average, and Worst Case)\n";
    std::cout << "  - Space Complexity: O(N) auxiliary merge buffers\n";
    std::cout << "  - Stability: Preserved (equal marks maintain original relative order)\n";
}

/**
 * 7. Display Students in Sorted ID Order (BST Inorder)
 */
void handleDisplaySortedID(const BST& bst) {
    bst.displayInorder();
    std::cout << "\n[ADSA Note] Inorder Traversal of Binary Search Tree (Left -> Root -> Right)\n";
    std::cout << "  - Traverses keys in strictly ascending order: O(N) time complexity.\n";
}

/**
 * 8. Display Balanced AVL Tree (Heights & Balance Factors)
 */
void handleDisplayAVL(const AVLTree& avl) {
    avl.displayAVLAnalytics();
    std::cout << "\n[ADSA Note] Self-Balancing AVL Tree maintains |Balance Factor| <= 1 for all nodes.\n";
    std::cout << "  - Rotations (LL, RR, LR, RL) guarantee O(log N) worst-case search and insert time.\n";
}

/**
 * 9. Save Records
 */
void handleSaveRecords(const BST& bst) {
    std::vector<Student> list;
    bst.getInorderStudents(list);

    bool success = FileManager::saveRecords(DATA_FILE, list);
    if (success) {
        std::cout << "\n[+] Success: " << list.size() << " student record(s) saved to '" << DATA_FILE << "'.\n";
    } else {
        std::cout << "\n[!] Failed to save records to file.\n";
    }
}

/**
 * Viva Demo: Compare BST vs AVL Tree Heights & Visualize Hash Buckets
 */
void handleCompareStructures(const BST& bst, const AVLTree& avl, const HashTable& ht) {
    std::cout << "\n=================================================================\n";
    std::cout << "          ADSA COMPARISON: BST vs AVL TREE vs HASH TABLE          \n";
    std::cout << "=================================================================\n";
    std::cout << " Total Records: " << bst.size() << "\n";
    std::cout << " Standard BST Height : " << bst.getTreeHeight() << " (Can degenerate to O(N) if skewed)\n";
    std::cout << " Balanced AVL Height : " << avl.getTreeHeight() << " (Strictly bounded by 1.44 * log2(N))\n";
    std::cout << " Hash Table Buckets  : 11 (Division method: hash(ID) = ID % 11)\n";
    std::cout << "-----------------------------------------------------------------\n";
    
    // Show Hash Table chains
    ht.displayBucketChains();
}

// ============================================================================
// MAIN APPLICATION ENTRY POINT
// ============================================================================

int main() {
    BST bst;
    AVLTree avl;
    HashTable ht;

    std::cout << "===================================================================\n";
    std::cout << "       WELCOME TO THE STUDENT RECORD MANAGEMENT SYSTEM (ADSA)       \n";
    std::cout << "     Features: Binary Search Tree, AVL Tree, Hash Table & Sort     \n";
    std::cout << "===================================================================\n";

    // Auto-load existing records from file on startup
    int loadedCount = 0;
    if (FileManager::loadRecords(DATA_FILE, bst, avl, ht, loadedCount)) {
        std::cout << "[+] Automatically loaded " << loadedCount << " record(s) from '" << DATA_FILE << "'.\n";
    } else {
        std::cout << "[i] Initial run: No existing data file found. Starting fresh.\n";
    }

    int choice = 0;
    while (true) {
        std::cout << "\n==================================================\n";
        std::cout << "                    MAIN MENU                     \n";
        std::cout << "==================================================\n";
        std::cout << "1. Add Student (BST, AVL & Hash Table)\n";
        std::cout << "2. Display All Students\n";
        std::cout << "3. Search Student by ID (Hash Table - O(1))\n";
        std::cout << "4. Update Student Details\n";
        std::cout << "5. Delete Student Record (BST Deletion Cases)\n";
        std::cout << "6. Sort Students by Marks (Merge Sort)\n";
        std::cout << "7. Display Students in Sorted ID Order (BST Inorder)\n";
        std::cout << "8. Display Balanced AVL Tree (Heights & Balance Factors)\n";
        std::cout << "9. Save Records\n";
        std::cout << "10. Exit\n";
        std::cout << "==================================================\n";
        std::cout << "[Viva Demo Tip: Option 11 compares BST vs AVL vs Hash Chains]\n";
        std::cout << "--------------------------------------------------\n";

        choice = readInt("Enter your choice (1-10): ", 1, 11);

        switch (choice) {
            case 1:
                handleAddStudent(bst, avl, ht);
                break;
            case 2:
                handleDisplayAll(bst);
                break;
            case 3:
                handleSearchStudent(ht);
                break;
            case 4:
                handleUpdateStudent(bst, avl, ht);
                break;
            case 5:
                handleDeleteStudent(bst, avl, ht);
                break;
            case 6:
                handleSortByMarks(bst);
                break;
            case 7:
                handleDisplaySortedID(bst);
                break;
            case 8:
                handleDisplayAVL(avl);
                break;
            case 9:
                handleSaveRecords(bst);
                break;
            case 10: {
                std::cout << "\nDo you want to save records before exiting? (y/n): ";
                char saveConfirm;
                std::cin >> saveConfirm;
                clearInputBuffer();
                if (saveConfirm == 'y' || saveConfirm == 'Y') {
                    handleSaveRecords(bst);
                }
                std::cout << "\nThank you for using the Student Record Management System. Goodbye!\n";
                return 0;
            }
            case 11:
                // Viva Demo Feature: Compare BST vs AVL Tree vs Hash Table
                handleCompareStructures(bst, avl, ht);
                break;
            default:
                std::cout << "[!] Invalid menu selection. Please try again.\n";
                break;
        }
    }

    return 0;
}
