#ifndef AVLTREE_H
#define AVLTREE_H

#include "Student.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

/**
 * @struct AVLNode
 * @brief Node representation for the self-balancing AVL Tree.
 *
 * Each node stores a Student record, pointers to left and right children,
 * and its current subtree height used to compute the Balance Factor.
 */
struct AVLNode {
    Student data;
    int height;
    AVLNode* left;
    AVLNode* right;

    AVLNode(const Student& s) : data(s), height(1), left(nullptr), right(nullptr) {}
};

/**
 * @class AVLTree
 * @brief Self-Balancing Binary Search Tree (Adelson-Velsky & Landis).
 *
 * Enforces the AVL Balance Property:
 *   For every node N, |Height(LeftSubtree) - Height(RightSubtree)| <= 1.
 *
 * Automatically executes tree rotations (LL, RR, LR, RL) upon insertion
 * and deletion, strictly guaranteeing O(log N) time complexity for search,
 * insert, and delete operations in all cases (including sorted inputs).
 */
class AVLTree {
private:
    AVLNode* root;
    int nodeCount;

    // Helper: Safely get height of a node (nullptr has height 0)
    int getHeight(AVLNode* node) const {
        return (node == nullptr) ? 0 : node->height;
    }

    // Helper: Compute Balance Factor = Height(Left) - Height(Right)
    int getBalanceFactor(AVLNode* node) const {
        return (node == nullptr) ? 0 : (getHeight(node->left) - getHeight(node->right));
    }

    // Helper: Update height of a node based on its children's heights
    void updateHeight(AVLNode* node) {
        if (node != nullptr) {
            node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
        }
    }

    /**
     * Right Rotation (RR Fix for Left-Left Heavy Imbalance)
     *
     *       y                              x
     *      / \                            / \
     *     x   T3   -- Right Rotate -->   T1  y
     *    / \                                / \
     *   T1  T2                             T2  T3
     */
    AVLNode* rightRotate(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;

        // Perform rotation
        x->right = y;
        y->left = T2;

        // Update heights
        updateHeight(y);
        updateHeight(x);

        // Return new subtree root
        return x;
    }

    /**
     * Left Rotation (LL Fix for Right-Right Heavy Imbalance)
     *
     *     x                                y
     *    / \                              / \
     *   T1  y     -- Left Rotate -->     x   T3
     *      / \                          / \
     *     T2  T3                       T1  T2
     */
    AVLNode* leftRotate(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;

        // Perform rotation
        y->left = x;
        x->right = T2;

        // Update heights
        updateHeight(x);
        updateHeight(y);

        // Return new subtree root
        return y;
    }

    // Helper: Find node with minimum ID (used for deletion successor)
    AVLNode* findMin(AVLNode* node) const {
        while (node != nullptr && node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    /**
     * Recursive AVL insertion with automatic rebalancing.
     */
    AVLNode* insertHelper(AVLNode* node, const Student& s, bool& inserted) {
        // Step 1: Standard BST Insertion
        if (node == nullptr) {
            inserted = true;
            nodeCount++;
            return new AVLNode(s);
        }

        if (s.getId() < node->data.getId()) {
            node->left = insertHelper(node->left, s, inserted);
        } else if (s.getId() > node->data.getId()) {
            node->right = insertHelper(node->right, s, inserted);
        } else {
            // Duplicate key rejected
            inserted = false;
            return node;
        }

        // Step 2: Update height of this ancestor node
        updateHeight(node);

        // Step 3: Get Balance Factor to check if rebalancing is required
        int balance = getBalanceFactor(node);

        // Step 4: Handle the 4 Imbalance Cases with Rotations

        // Case 1: Left-Left (LL) Imbalance -> Single Right Rotation
        if (balance > 1 && s.getId() < node->left->data.getId()) {
            return rightRotate(node);
        }

        // Case 2: Right-Right (RR) Imbalance -> Single Left Rotation
        if (balance < -1 && s.getId() > node->right->data.getId()) {
            return leftRotate(node);
        }

        // Case 3: Left-Right (LR) Imbalance -> Left Rotate Child, then Right Rotate Parent
        if (balance > 1 && s.getId() > node->left->data.getId()) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        // Case 4: Right-Left (RL) Imbalance -> Right Rotate Child, then Left Rotate Parent
        if (balance < -1 && s.getId() < node->right->data.getId()) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        // Subtree remains balanced
        return node;
    }

    /**
     * Recursive AVL deletion with automatic rebalancing.
     */
    AVLNode* deleteHelper(AVLNode* node, int id, bool& deleted) {
        if (node == nullptr) {
            deleted = false;
            return nullptr;
        }

        // Step 1: Standard BST Deletion
        if (id < node->data.getId()) {
            node->left = deleteHelper(node->left, id, deleted);
        } else if (id > node->data.getId()) {
            node->right = deleteHelper(node->right, id, deleted);
        } else {
            // Found node to delete
            deleted = true;

            // Node with 0 or 1 child
            if (node->left == nullptr || node->right == nullptr) {
                AVLNode* temp = (node->left != nullptr) ? node->left : node->right;
                if (temp == nullptr) {
                    // 0 children (Leaf)
                    temp = node;
                    node = nullptr;
                } else {
                    // 1 child
                    *node = *temp; // Copy contents
                }
                delete temp;
                nodeCount--;
            } else {
                // Node with 2 children: Get Inorder Successor
                AVLNode* successor = findMin(node->right);
                node->data = successor->data;
                bool dummy = false;
                node->right = deleteHelper(node->right, successor->data.getId(), dummy);
            }
        }

        // If tree had only one node
        if (node == nullptr) {
            return nullptr;
        }

        // Step 2: Update height
        updateHeight(node);

        // Step 3: Check Balance Factor
        int balance = getBalanceFactor(node);

        // Step 4: Rebalance if necessary

        // Left-Left Case
        if (balance > 1 && getBalanceFactor(node->left) >= 0) {
            return rightRotate(node);
        }

        // Left-Right Case
        if (balance > 1 && getBalanceFactor(node->left) < 0) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        // Right-Right Case
        if (balance < -1 && getBalanceFactor(node->right) <= 0) {
            return leftRotate(node);
        }

        // Right-Left Case
        if (balance < -1 && getBalanceFactor(node->right) > 0) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    // Helper: Search
    AVLNode* searchHelper(AVLNode* node, int id) const {
        if (node == nullptr || node->data.getId() == id) {
            return node;
        }
        if (id < node->data.getId()) {
            return searchHelper(node->left, id);
        }
        return searchHelper(node->right, id);
    }

    // Helper: Inorder Traversal
    void inorderHelper(AVLNode* node, std::vector<Student>& list) const {
        if (node != nullptr) {
            inorderHelper(node->left, list);
            list.push_back(node->data);
            inorderHelper(node->right, list);
        }
    }

    // Helper: Inorder traversal collecting node balance analytics
    void collectAnalytics(AVLNode* node, std::vector<std::pair<Student, std::pair<int, int>>>& analytics) const {
        if (node != nullptr) {
            collectAnalytics(node->left, analytics);
            analytics.push_back({node->data, {node->height, getBalanceFactor(node)}});
            collectAnalytics(node->right, analytics);
        }
    }

    // Helper: Free memory
    void destroyTree(AVLNode* node) {
        if (node != nullptr) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }

public:
    AVLTree() : root(nullptr), nodeCount(0) {}

    ~AVLTree() {
        clear();
    }

    // Insert student with self-balancing rotations
    bool insert(const Student& s) {
        bool inserted = false;
        root = insertHelper(root, s, inserted);
        return inserted;
    }

    // Search student by ID
    bool search(int id, Student& result) const {
        AVLNode* node = searchHelper(root, id);
        if (node != nullptr) {
            result = node->data;
            return true;
        }
        return false;
    }

    // Update existing student details
    bool update(const Student& s) {
        AVLNode* node = searchHelper(root, s.getId());
        if (node != nullptr) {
            node->data = s;
            return true;
        }
        return false;
    }

    // Delete student with self-balancing re-rotation
    bool remove(int id) {
        bool deleted = false;
        root = deleteHelper(root, id, deleted);
        return deleted;
    }

    bool contains(int id) const {
        return (searchHelper(root, id) != nullptr);
    }

    // Collect all records in sorted ID order
    void getInorderStudents(std::vector<Student>& list) const {
        list.clear();
        inorderHelper(root, list);
    }

    int getTreeHeight() const {
        return getHeight(root);
    }

    int size() const {
        return nodeCount;
    }

    bool isEmpty() const {
        return (root == nullptr);
    }

    void clear() {
        destroyTree(root);
        root = nullptr;
        nodeCount = 0;
    }

    /**
     * Viva & Academic Demonstration:
     * Displays all AVL nodes with their Heights and Balance Factors,
     * proving that every node strictly satisfies |BF| <= 1.
     */
    void displayAVLAnalytics() const {
        std::vector<std::pair<Student, std::pair<int, int>>> analytics;
        collectAnalytics(root, analytics);

        if (analytics.empty()) {
            std::cout << "\n[!] AVL Tree is currently empty.\n";
            return;
        }

        std::cout << "\n=========================================================================================\n";
        std::cout << "                  SELF-BALANCING AVL TREE NODE ANALYTICS & BALANCE FACTORS               \n";
        std::cout << "=========================================================================================\n";
        std::cout << "Total Nodes: " << nodeCount << " | Overall AVL Tree Height: " << getHeight(root) << "\n";
        std::cout << "AVL Balance Property: For every node, Balance Factor in {-1, 0, +1}\n";
        std::cout << "-----------------------------------------------------------------------------------------\n";

        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(16, '-')
                  << "+" << std::string(16, '-') << "+\n";

        std::cout << "| " << std::left << std::setw(6)  << "ID"
                  << "| " << std::left << std::setw(20) << "Name"
                  << "| " << std::left << std::setw(12) << "Department"
                  << "| " << std::left << std::setw(8)  << "Height"
                  << "| " << std::left << std::setw(14) << "Balance Factor"
                  << "| " << std::left << std::setw(14) << "Status"
                  << "|\n";

        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(16, '-')
                  << "+" << std::string(16, '-') << "+\n";

        for (const auto& item : analytics) {
            const Student& s = item.first;
            int h = item.second.first;
            int bf = item.second.second;

            std::string status = (std::abs(bf) <= 1) ? "BALANCED" : "UNBALANCED";

            std::cout << "| " << std::left << std::setw(6)  << s.getId()
                      << "| " << std::left << std::setw(20) << (s.getName().length() > 20 ? s.getName().substr(0, 17) + "..." : s.getName())
                      << "| " << std::left << std::setw(12) << s.getDepartment()
                      << "| " << std::left << std::setw(8)  << h
                      << "| " << std::left << std::setw(14) << (bf > 0 ? "+" + std::to_string(bf) : std::to_string(bf))
                      << "| " << std::left << std::setw(14) << status
                      << "|\n";
        }

        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(16, '-')
                  << "+" << std::string(16, '-') << "+\n";
    }
};

#endif // AVLTREE_H
