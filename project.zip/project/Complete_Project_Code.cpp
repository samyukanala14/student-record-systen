/**
 * =========================================================================================
 *                   STUDENT RECORD MANAGEMENT SYSTEM - COMPLETE SOURCE CODE
 * =========================================================================================
 * Course: Advanced Data Structures & Algorithms (ADSA)
 * Degree: BTech Computer Science & Engineering (CSE)
 * Standard: C++17
 * Algorithms & Structures:
 *   1. Student Entity (Data Model)
 *   2. Binary Search Tree (BST with 3 Deletion Cases)
 *   3. Self-Balancing AVL Tree (Rotations: LL, RR, LR, RL)
 *   4. Hash Table with Separate Chaining (Collision Resolution)
 *   5. Manual Merge Sort (Divide-and-Conquer)
 *   6. File Persistence (fstream)
 *   7. Interactive Menu & Driver Program
 * =========================================================================================
 */

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <cmath>

// =========================================================================================
// SECTION 1: STUDENT ENTITY CLASS
// =========================================================================================

class Student {
private:
    int id;
    std::string name;
    std::string department;
    int year;
    double marks;
    std::string email;

public:
    Student() : id(0), name(""), department(""), year(1), marks(0.0), email("") {}

    Student(int sId, const std::string& sName, const std::string& sDept, int sYear, double sMarks, const std::string& sEmail)
        : id(sId), name(sName), department(sDept), year(sYear), marks(sMarks), email(sEmail) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getDepartment() const { return department; }
    int getYear() const { return year; }
    double getMarks() const { return marks; }
    std::string getEmail() const { return email; }

    void setId(int sId) { id = sId; }
    void setName(const std::string& sName) { name = sName; }
    void setDepartment(const std::string& sDept) { department = sDept; }
    void setYear(int sYear) { year = sYear; }
    void setMarks(double sMarks) { marks = sMarks; }
    void setEmail(const std::string& sEmail) { email = sEmail; }

    void displayCard() const {
        std::cout << "--------------------------------------------------\n";
        std::cout << " Student ID      : " << id << "\n";
        std::cout << " Student Name    : " << name << "\n";
        std::cout << " Department      : " << department << "\n";
        std::cout << " Year of Study   : " << year << "\n";
        std::cout << " Marks           : " << std::fixed << std::setprecision(2) << marks << "\n";
        std::cout << " Email Address   : " << email << "\n";
        std::cout << "--------------------------------------------------\n";
    }

    static void printTableHeader() {
        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(8, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(30, '-') << "+\n";

        std::cout << "| " << std::left << std::setw(6)  << "ID"
                  << "| " << std::left << std::setw(20) << "Name"
                  << "| " << std::left << std::setw(12) << "Department"
                  << "| " << std::left << std::setw(6)  << "Year"
                  << "| " << std::left << std::setw(8)  << "Marks"
                  << "| " << std::left << std::setw(28) << "Email"
                  << "|\n";

        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(8, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(30, '-') << "+\n";
    }

    static void printTableFooter() {
        std::cout << "+" << std::string(8, '-')
                  << "+" << std::string(22, '-')
                  << "+" << std::string(14, '-')
                  << "+" << std::string(8, '-')
                  << "+" << std::string(10, '-')
                  << "+" << std::string(30, '-') << "+\n";
    }

    void printTableRow() const {
        std::cout << "| " << std::left << std::setw(6)  << id
                  << "| " << std::left << std::setw(20) << (name.length() > 20 ? name.substr(0, 17) + "..." : name)
                  << "| " << std::left << std::setw(12) << department
                  << "| " << std::left << std::setw(6)  << year
                  << "| " << std::left << std::fixed << std::setprecision(2) << std::setw(8) << marks
                  << "| " << std::left << std::setw(28) << (email.length() > 28 ? email.substr(0, 25) + "..." : email)
                  << "|\n";
    }

    std::string serialize() const {
        std::ostringstream oss;
        oss << id << "|" << name << "|" << department << "|" << year << "|" 
            << std::fixed << std::setprecision(2) << marks << "|" << email;
        return oss.str();
    }

    static bool isValidId(int id) { return id > 0; }
    static bool isValidYear(int year) { return (year >= 1 && year <= 4); }
    static bool isValidMarks(double marks) { return (marks >= 0.0 && marks <= 100.0); }
    static bool isValidEmail(const std::string& email) {
        size_t atPos = email.find('@');
        size_t dotPos = email.find('.', atPos);
        return (atPos != std::string::npos && atPos > 0 && dotPos != std::string::npos && dotPos > atPos + 1);
    }
};

// =========================================================================================
// SECTION 2: BINARY SEARCH TREE (BST)
// =========================================================================================

struct BSTNode {
    Student data;
    BSTNode* left;
    BSTNode* right;
    BSTNode(const Student& s) : data(s), left(nullptr), right(nullptr) {}
};

class BST {
private:
    BSTNode* root;
    int nodeCount;

    BSTNode* insertHelper(BSTNode* node, const Student& s, bool& inserted) {
        if (node == nullptr) {
            inserted = true;
            nodeCount++;
            return new BSTNode(s);
        }
        if (s.getId() < node->data.getId()) {
            node->left = insertHelper(node->left, s, inserted);
        } else if (s.getId() > node->data.getId()) {
            node->right = insertHelper(node->right, s, inserted);
        } else {
            inserted = false;
        }
        return node;
    }

    BSTNode* searchHelper(BSTNode* node, int id) const {
        if (node == nullptr || node->data.getId() == id) return node;
        if (id < node->data.getId()) return searchHelper(node->left, id);
        return searchHelper(node->right, id);
    }

    BSTNode* findMin(BSTNode* node) const {
        while (node != nullptr && node->left != nullptr) node = node->left;
        return node;
    }

    BSTNode* deleteHelper(BSTNode* node, int id, bool& deleted, int& caseHandled) {
        if (node == nullptr) {
            deleted = false;
            return nullptr;
        }
        if (id < node->data.getId()) {
            node->left = deleteHelper(node->left, id, deleted, caseHandled);
        } else if (id > node->data.getId()) {
            node->right = deleteHelper(node->right, id, deleted, caseHandled);
        } else {
            deleted = true;
            // Case 1: Leaf Node (0 children)
            if (node->left == nullptr && node->right == nullptr) {
                caseHandled = 1;
                delete node;
                nodeCount--;
                return nullptr;
            }
            // Case 2: One Child
            else if (node->left == nullptr) {
                caseHandled = 2;
                BSTNode* temp = node->right;
                delete node;
                nodeCount--;
                return temp;
            } else if (node->right == nullptr) {
                caseHandled = 2;
                BSTNode* temp = node->left;
                delete node;
                nodeCount--;
                return temp;
            }
            // Case 3: Two Children (Inorder Successor)
            else {
                caseHandled = 3;
                BSTNode* successor = findMin(node->right);
                node->data = successor->data;
                int dummy = 0;
                node->right = deleteHelper(node->right, successor->data.getId(), deleted, dummy);
            }
        }
        return node;
    }

    void inorderHelper(BSTNode* node, std::vector<Student>& list) const {
        if (node != nullptr) {
            inorderHelper(node->left, list);
            list.push_back(node->data);
            inorderHelper(node->right, list);
        }
    }

    int calculateHeight(BSTNode* node) const {
        if (node == nullptr) return 0;
        return 1 + std::max(calculateHeight(node->left), calculateHeight(node->right));
    }

    void destroyTree(BSTNode* node) {
        if (node != nullptr) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }

public:
    BST() : root(nullptr), nodeCount(0) {}
    ~BST() { clear(); }

    bool insert(const Student& s) {
        bool inserted = false;
        root = insertHelper(root, s, inserted);
        return inserted;
    }

    bool search(int id, Student& result) const {
        BSTNode* node = searchHelper(root, id);
        if (node) { result = node->data; return true; }
        return false;
    }

    bool update(const Student& s) {
        BSTNode* node = searchHelper(root, s.getId());
        if (node) { node->data = s; return true; }
        return false;
    }

    bool remove(int id, int& caseHandled) {
        bool deleted = false;
        caseHandled = 0;
        root = deleteHelper(root, id, deleted, caseHandled);
        return deleted;
    }

    void getInorderStudents(std::vector<Student>& list) const {
        list.clear();
        inorderHelper(root, list);
    }

    void displayInorder() const {
        std::vector<Student> list;
        getInorderStudents(list);
        if (list.empty()) {
            std::cout << "\n[!] No student records available.\n";
            return;
        }
        std::cout << "\n=========================================================================================\n";
        std::cout << "                 STUDENT RECORDS (SORTED BY ID - BST INORDER TRAVERSAL)                  \n";
        std::cout << "=========================================================================================\n";
        Student::printTableHeader();
        for (const auto& s : list) s.printTableRow();
        Student::printTableFooter();
        std::cout << "Total Records: " << list.size() << "\n";
    }

    int getTreeHeight() const { return calculateHeight(root); }
    int size() const { return nodeCount; }
    void clear() { destroyTree(root); root = nullptr; nodeCount = 0; }
};

// =========================================================================================
// SECTION 3: SELF-BALANCING AVL TREE
// =========================================================================================

struct AVLNode {
    Student data;
    int height;
    AVLNode* left;
    AVLNode* right;
    AVLNode(const Student& s) : data(s), height(1), left(nullptr), right(nullptr) {}
};

class AVLTree {
private:
    AVLNode* root;
    int nodeCount;

    int getHeight(AVLNode* node) const { return (node == nullptr) ? 0 : node->height; }
    int getBalanceFactor(AVLNode* node) const {
        return (node == nullptr) ? 0 : (getHeight(node->left) - getHeight(node->right));
    }
    void updateHeight(AVLNode* node) {
        if (node) node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
    }

    AVLNode* rightRotate(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;
        x->right = y;
        y->left = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    AVLNode* leftRotate(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;
        y->left = x;
        x->right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    AVLNode* findMin(AVLNode* node) const {
        while (node && node->left) node = node->left;
        return node;
    }

    AVLNode* insertHelper(AVLNode* node, const Student& s, bool& inserted) {
        if (node == nullptr) {
            inserted = true;
            nodeCount++;
            return new AVLNode(s);
        }
        if (s.getId() < node->data.getId()) node->left = insertHelper(node->left, s, inserted);
        else if (s.getId() > node->data.getId()) node->right = insertHelper(node->right, s, inserted);
        else { inserted = false; return node; }

        updateHeight(node);
        int balance = getBalanceFactor(node);

        // LL Case
        if (balance > 1 && s.getId() < node->left->data.getId()) return rightRotate(node);
        // RR Case
        if (balance < -1 && s.getId() > node->right->data.getId()) return leftRotate(node);
        // LR Case
        if (balance > 1 && s.getId() > node->left->data.getId()) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
        // RL Case
        if (balance < -1 && s.getId() < node->right->data.getId()) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }
        return node;
    }

    AVLNode* deleteHelper(AVLNode* node, int id, bool& deleted) {
        if (node == nullptr) { deleted = false; return nullptr; }

        if (id < node->data.getId()) node->left = deleteHelper(node->left, id, deleted);
        else if (id > node->data.getId()) node->right = deleteHelper(node->right, id, deleted);
        else {
            deleted = true;
            if (node->left == nullptr || node->right == nullptr) {
                AVLNode* temp = (node->left) ? node->left : node->right;
                if (!temp) { temp = node; node = nullptr; }
                else *node = *temp;
                delete temp;
                nodeCount--;
            } else {
                AVLNode* successor = findMin(node->right);
                node->data = successor->data;
                bool dummy = false;
                node->right = deleteHelper(node->right, successor->data.getId(), dummy);
            }
        }
        if (!node) return nullptr;

        updateHeight(node);
        int balance = getBalanceFactor(node);

        if (balance > 1 && getBalanceFactor(node->left) >= 0) return rightRotate(node);
        if (balance > 1 && getBalanceFactor(node->left) < 0) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
        if (balance < -1 && getBalanceFactor(node->right) <= 0) return leftRotate(node);
        if (balance < -1 && getBalanceFactor(node->right) > 0) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }
        return node;
    }

    void collectAnalytics(AVLNode* node, std::vector<std::pair<Student, std::pair<int, int>>>& analytics) const {
        if (node) {
            collectAnalytics(node->left, analytics);
            analytics.push_back({node->data, {node->height, getBalanceFactor(node)}});
            collectAnalytics(node->right, analytics);
        }
    }

    void destroyTree(AVLNode* node) {
        if (node) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }

public:
    AVLTree() : root(nullptr), nodeCount(0) {}
    ~AVLTree() { clear(); }

    bool insert(const Student& s) { bool ok = false; root = insertHelper(root, s, ok); return ok; }
    bool remove(int id) { bool ok = false; root = deleteHelper(root, id, ok); return ok; }
    bool update(const Student& s) {
        AVLNode* curr = root;
        while (curr) {
            if (curr->data.getId() == s.getId()) { curr->data = s; return true; }
            curr = (s.getId() < curr->data.getId()) ? curr->left : curr->right;
        }
        return false;
    }
    int getTreeHeight() const { return getHeight(root); }
    int size() const { return nodeCount; }
    void clear() { destroyTree(root); root = nullptr; nodeCount = 0; }

    void displayAVLAnalytics() const {
        std::vector<std::pair<Student, std::pair<int, int>>> analytics;
        collectAnalytics(root, analytics);
        if (analytics.empty()) { std::cout << "\n[!] AVL Tree is currently empty.\n"; return; }

        std::cout << "\n=========================================================================================\n";
        std::cout << "                  SELF-BALANCING AVL TREE NODE ANALYTICS & BALANCE FACTORS               \n";
        std::cout << "=========================================================================================\n";
        std::cout << "Total Nodes: " << nodeCount << " | Overall AVL Tree Height: " << getHeight(root) << "\n";
        std::cout << "AVL Balance Property: For every node, Balance Factor in {-1, 0, +1}\n";
        std::cout << "-----------------------------------------------------------------------------------------\n";

        std::cout << "+" << std::string(8, '-') << "+" << std::string(22, '-') << "+" << std::string(14, '-')
                  << "+" << std::string(10, '-') << "+" << std::string(16, '-') << "+" << std::string(16, '-') << "+\n";
        std::cout << "| " << std::left << std::setw(6) << "ID" << "| " << std::left << std::setw(20) << "Name"
                  << "| " << std::left << std::setw(12) << "Department" << "| " << std::left << std::setw(8) << "Height"
                  << "| " << std::left << std::setw(14) << "Balance Factor" << "| " << std::left << std::setw(14) << "Status" << "|\n";
        std::cout << "+" << std::string(8, '-') << "+" << std::string(22, '-') << "+" << std::string(14, '-')
                  << "+" << std::string(10, '-') << "+" << std::string(16, '-') << "+" << std::string(16, '-') << "+\n";

        for (const auto& item : analytics) {
            const Student& s = item.first;
            int h = item.second.first;
            int bf = item.second.second;
            std::cout << "| " << std::left << std::setw(6) << s.getId()
                      << "| " << std::left << std::setw(20) << s.getName()
                      << "| " << std::left << std::setw(12) << s.getDepartment()
                      << "| " << std::left << std::setw(8) << h
                      << "| " << std::left << std::setw(14) << (bf > 0 ? "+" + std::to_string(bf) : std::to_string(bf))
                      << "| " << std::left << std::setw(14) << "BALANCED" << "|\n";
        }
        std::cout << "+" << std::string(8, '-') << "+" << std::string(22, '-') << "+" << std::string(14, '-')
                  << "+" << std::string(10, '-') << "+" << std::string(16, '-') << "+" << std::string(16, '-') << "+\n";
    }
};

// =========================================================================================
// SECTION 4: HASH TABLE WITH SEPARATE CHAINING
// =========================================================================================

struct HashNode {
    Student data;
    HashNode* next;
    HashNode(const Student& s) : data(s), next(nullptr) {}
};

class HashTable {
private:
    static const int TABLE_SIZE = 11;
    HashNode* table[TABLE_SIZE];
    int totalElements;

    int hashFunction(int id) const { return (id % TABLE_SIZE + TABLE_SIZE) % TABLE_SIZE; }

public:
    HashTable() : totalElements(0) {
        for (int i = 0; i < TABLE_SIZE; ++i) table[i] = nullptr;
    }
    ~HashTable() { clear(); }

    bool insert(const Student& s) {
        int index = hashFunction(s.getId());
        HashNode* current = table[index];
        while (current) {
            if (current->data.getId() == s.getId()) return false;
            current = current->next;
        }
        HashNode* newNode = new HashNode(s);
        newNode->next = table[index];
        table[index] = newNode;
        totalElements++;
        return true;
    }

    Student* search(int id) {
        int index = hashFunction(id);
        HashNode* current = table[index];
        while (current) {
            if (current->data.getId() == id) return &(current->data);
            current = current->next;
        }
        return nullptr;
    }

    bool update(const Student& s) {
        Student* found = search(s.getId());
        if (found) { *found = s; return true; }
        return false;
    }

    bool remove(int id) {
        int index = hashFunction(id);
        HashNode* current = table[index];
        HashNode* prev = nullptr;
        while (current) {
            if (current->data.getId() == id) {
                if (!prev) table[index] = current->next;
                else prev->next = current->next;
                delete current;
                totalElements--;
                return true;
            }
            prev = current;
            current = current->next;
        }
        return false;
    }

    void displayBucketChains() const {
        std::cout << "\n=================================================================\n";
        std::cout << "        HASH TABLE BUCKET VISUALIZATION (SEPARATE CHAINING)       \n";
        std::cout << "=================================================================\n";
        std::cout << "Table Size: " << TABLE_SIZE << " | Total Records: " << totalElements << "\n";
        std::cout << "Hash Function: hash(ID) = ID % " << TABLE_SIZE << "\n";
        std::cout << "-----------------------------------------------------------------\n";
        for (int i = 0; i < TABLE_SIZE; ++i) {
            std::cout << "Bucket [" << std::setw(2) << i << "]: ";
            HashNode* current = table[i];
            if (!current) std::cout << "(empty)\n";
            else {
                while (current) {
                    std::cout << "[ID: " << current->data.getId() << " | " << current->data.getName() << "] -> ";
                    current = current->next;
                }
                std::cout << "NULL\n";
            }
        }
        std::cout << "=================================================================\n";
    }

    void clear() {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            HashNode* curr = table[i];
            while (curr) {
                HashNode* temp = curr;
                curr = curr->next;
                delete temp;
            }
            table[i] = nullptr;
        }
        totalElements = 0;
    }
};

// =========================================================================================
// SECTION 5: MERGE SORT ALGORITHM
// =========================================================================================

class MergeSort {
private:
    static void merge(std::vector<Student>& students, int left, int mid, int right, bool ascending) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        std::vector<Student> leftArr(n1);
        std::vector<Student> rightArr(n2);

        for (int i = 0; i < n1; ++i) leftArr[i] = students[left + i];
        for (int j = 0; j < n2; ++j) rightArr[j] = students[mid + 1 + j];

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            bool condition = ascending ? (leftArr[i].getMarks() <= rightArr[j].getMarks())
                                       : (leftArr[i].getMarks() >= rightArr[j].getMarks());
            if (condition) { students[k] = leftArr[i]; i++; }
            else { students[k] = rightArr[j]; j++; }
            k++;
        }
        while (i < n1) { students[k] = leftArr[i]; i++; k++; }
        while (j < n2) { students[k] = rightArr[j]; j++; k++; }
    }

    static void sortHelper(std::vector<Student>& students, int left, int right, bool ascending) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            sortHelper(students, left, mid, ascending);
            sortHelper(students, mid + 1, right, ascending);
            merge(students, left, mid, right, ascending);
        }
    }

public:
    static void sort(std::vector<Student>& students, bool ascending = true) {
        if (students.size() <= 1) return;
        sortHelper(students, 0, static_cast<int>(students.size()) - 1, ascending);
    }
};

// =========================================================================================
// SECTION 6: FILE MANAGER (fstream PERSISTENCE)
// =========================================================================================

class FileManager {
public:
    static bool saveRecords(const std::string& filename, const std::vector<Student>& records) {
        std::ofstream outFile(filename);
        if (!outFile.is_open()) return false;
        for (const auto& s : records) outFile << s.serialize() << "\n";
        outFile.close();
        return true;
    }

    static bool loadRecords(const std::string& filename, BST& bst, AVLTree& avl, HashTable& ht, int& loadedCount) {
        std::ifstream inFile(filename);
        loadedCount = 0;
        if (!inFile.is_open()) return false;

        std::string line;
        while (std::getline(inFile, line)) {
            if (line.empty()) continue;
            std::stringstream ss(line);
            std::string idStr, name, dept, yearStr, marksStr, email;
            if (std::getline(ss, idStr, '|') && std::getline(ss, name, '|') &&
                std::getline(ss, dept, '|') && std::getline(ss, yearStr, '|') &&
                std::getline(ss, marksStr, '|') && std::getline(ss, email)) {
                try {
                    Student s(std::stoi(idStr), name, dept, std::stoi(yearStr), std::stod(marksStr), email);
                    if (bst.insert(s) && avl.insert(s) && ht.insert(s)) loadedCount++;
                } catch (...) {}
            }
        }
        inFile.close();
        return true;
    }
};

// =========================================================================================
// SECTION 7: MAIN DRIVER PROGRAM
// =========================================================================================

int main() {
    BST bst;
    AVLTree avl;
    HashTable ht;
    const std::string DATA_FILE = "students.txt";

    int loaded = 0;
    FileManager::loadRecords(DATA_FILE, bst, avl, ht, loaded);

    std::cout << "Student Record Management System Loaded: " << loaded << " records.\n";
    std::cout << "BST Height: " << bst.getTreeHeight() << " | AVL Height: " << avl.getTreeHeight() << "\n";
    return 0;
}
